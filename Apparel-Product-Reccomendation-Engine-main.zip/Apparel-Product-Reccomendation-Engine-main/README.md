This Apparel Product Reccomendation Engine project.

Applied Natural Language Feature Engineering and built a content-based recommendation system using NLP models (Bag of Words and TF-IDF) in problem of recommending similar products on e-commerce websites by Amazon product advertising API. 
and Tech Stack used are Python, Bag of Words, TF-IDF, Word2Vec, NLP.

